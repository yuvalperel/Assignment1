﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project
{
    public partial class ReturnsForm : Form
    {
        private Library library;
        private Member currentMember;
        public ReturnsForm(Library library, Member member)
        {
            InitializeComponent();
            this.library = library;
            this.currentMember = member;
        }

        private void ReturnsForm_Load(object sender, EventArgs e)
        {
            // Load borrowed books into the ListBox
            LoadBorrowedBooks();
        }

        private void LoadBorrowedBooks()
        {
            listBox1.Items.Clear(); // Clear existing items

            var borrowedBooks = currentMember.BorrowedBooks.Where(b => b.IsBorrowed).ToList();

            if (borrowedBooks.Count > 0)
            {
                foreach (var book in borrowedBooks)
                {
                    listBox1.Items.Add($"{book.BookName} (Due: {book.ReturnDate.Value.ToShortDateString()})");
                }
            }
            else
            {
                listBox1.Items.Add("No borrowed books to return.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Get the selected book from the ListBox
            var selectedBookTitle = listBox1.SelectedItem?.ToString()?.Split('(')[0].Trim();

            if (string.IsNullOrEmpty(selectedBookTitle) || selectedBookTitle == "No borrowed books to return.")
            {
                MessageBox.Show("Please select a book to return.");
                return;
            }

            // Find the selected book in the member's borrowed books
            var bookToReturn = currentMember.BorrowedBooks
                .FirstOrDefault(b => b.BookName.Equals(selectedBookTitle, StringComparison.OrdinalIgnoreCase));

            if (bookToReturn != null)
            {
                // Update the book's IsBorrowed status
                bookToReturn.IsBorrowed = false;

                // Remove the book from the member's list of borrowed books
                currentMember.BorrowedBooks.Remove(bookToReturn);

                // Convert from Book to BookReview
                BookReview bookToReview = new BookReview(
                    bookToReturn.BookName,
                    bookToReturn.BookGenre,
                    bookToReturn.BookAuthor,
                    bookToReturn.PublicationDate,
                    bookToReturn.Summary);

                // Check if the book is already in the returned books list
                if (!currentMember.ReturnedBooks.Any(b => b.BookName.Equals(bookToReview.BookName, StringComparison.OrdinalIgnoreCase)))
                {
                    // Add the book to the member's list of returned books
                    currentMember.ReturnedBooks.Add(bookToReview);
                    MessageBox.Show($"{bookToReturn.BookName} has been returned successfully.");
                }
                else
                {
                    MessageBox.Show("This book is already in your list of returned books.");
                }

                LoadBorrowedBooks(); // Refresh the list
            }
            else
            {
                MessageBox.Show("Selected book not found in borrowed books.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the current form
            OptionForm form2 = new OptionForm(library, currentMember);
            form2.Show();
        }

    }
}
