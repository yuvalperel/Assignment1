﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project
{
    public class Member
    {
        // Private fields
        private string memberID;
        private string firstName;
        private string lastName;
        private List<Book> borrowedBooks;
        private List<BookReview> returnedBooks; // Field to contain books that have been borrowed and returned

        // Public properties memberID
        public string MemberID
        {
            get { return memberID; }
            set
            {
                if (IsValidId(value))
                {
                    memberID = value;
                }
                else
                {
                    throw new ArgumentException("Invalid Member ID. It must be a 9-digit number.");
                }
            }
        }

        // Private method for validating the ID
        private bool IsValidId(string id)
        {
            // Check if the ID is 9 digits long and contains only digits
            return id.Length == 9 && id.All(char.IsDigit);
        }

        // Public properties firstname
        public string FirstName
        {
            get { return firstName; }
            set
            {
                if (IsValidName(value))
                {
                    firstName = value;
                }
                else
                {
                    throw new ArgumentException("Member first name cannot be empty and must contain only letters.");
                }
            }
        }

        // Public properties lastname
        public string LastName
        {
            get { return lastName; }
            set
            {
                if (IsValidName(value))
                {
                    lastName = value;
                }
                else
                {
                    throw new ArgumentException("Member last name cannot be empty and must contain only letters.");
                }
            }
        }

        // Private method for validate name
        private bool IsValidName(string name)
        {
            // Check if the name contains only chars
            return name.Length != 0 && name.All(Char.IsLetter);
        }

        // Public properties borrowedBooks
        public List<Book> BorrowedBooks
        {
            get { return borrowedBooks; }
        }

        // Public properties returnedBooks
        public List<BookReview> ReturnedBooks
        {
            get { return returnedBooks; }
        }

        // Constructor
        public Member(string memberId, string firstName, string lastName)
        {
            MemberID = memberId; // Will validate through the property
            FirstName = firstName; // Will validate through the property
            LastName = lastName; // Will validate through the property
            borrowedBooks = new List<Book>(); // Create an empty list of borrowed books
            returnedBooks = new List<BookReview>(); // Create an empty list of returned books
        }

    }
}

