﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project
{
    public class Book
    {
        // Enum for Book Genre
        public enum Genre
        {
            Mystery = 0,
            Fantasy = 1,
            Biography = 2,
            ScienceFiction = 3,
            Romance = 4,
            Thriller = 5,
            Adventure = 6,
        }

        // Private fields
        private string bookname;
        private Genre bookgenre;
        private string bookauthor;
        private DateTime publicationDate;
        private string summary;
        private bool isBorrowed;
        private DateTime? returnDate; // Nullable DateTime
        
        // Public properties
        public string BookName
        {
            get { return bookname; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Book name cannot be empty.");
                }
                bookname = value;
            }
        }

        public Genre BookGenre
        {
            get { return bookgenre; }
            set { bookgenre = value; }
        }

        public string BookAuthor
        {
            get { return bookauthor; }
            set { bookauthor = value; }
        }

        public DateTime PublicationDate
        {
            get { return publicationDate; }
            set
            {
                if (value <= DateTime.Today)
                {
                    publicationDate = value;
                }
                else
                {
                    throw new ArgumentException("Publication date cannot be in the future.");
                }
            }
        }

        public string Summary
        {
            get { return summary; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Summary cannot be empty.");
                }
                summary = value;
            }
        }

        public bool IsBorrowed
        {
            get { return isBorrowed; }
            set { isBorrowed = value; }
        }

        public DateTime? ReturnDate
        {
            get { return returnDate; }
            set { returnDate = value; }
        }

        // Constructors
        public Book(string name, Genre genre, string author, DateTime publicationDate, string summary)
        {
            BookName = name;
            BookGenre = genre;
            BookAuthor = author;
            PublicationDate = publicationDate;
            Summary = summary;
            IsBorrowed = false;
            returnDate = null; // No return date when book is not borrowed

        }
    }
}

