﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project
{
    public partial class ReviewReadForm : Form
    {
        private Library library; // Instance of Library
        private Member currentMember; // Instance of the current member
        public ReviewReadForm(Library library, Member currentMember)
        {
            InitializeComponent();
            this.library = library;
            this.currentMember = currentMember;
        }

        private void ReviewReadForm_Load(object sender, EventArgs e)
        {
            booksComboBox.DataSource = null; // Clear the data source
        }

        private void comboBox1_DropDown(object sender, EventArgs e)
        {
            // Load books into the ComboBox only when the dropdown is opened
            booksComboBox.DataSource = library.Books.Select(b => b.BookName).ToList();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (booksComboBox.SelectedItem == null) return;

            string selectedBookName = booksComboBox.SelectedItem.ToString();
            // Get the corresponding BookReview for the selected book name
            var selectedBook = library.BookReviews.FirstOrDefault(b => b.BookName == selectedBookName);

            reviewsListBox.Items.Clear(); // Clear previous items

            // Check if there are any reviews and display them
            if (selectedBook != null)
            {
                foreach (var review in selectedBook.Reviews)
                {
                    reviewsListBox.Items.Add($"Rating: {review.Rating} - {review.ReviewText}");
                }

                 // Display the average rating
                 double averageRating = selectedBook.AverageRating;
                 averageRatingLabel.Text = $"{averageRating:F1}"; 
            }
            else
            {
                reviewsListBox.Items.Add("No reviews available for this book.");
                averageRatingLabel.Text = "No rating yet"; // Update average rating label if no reviews
            }

            // Update the height of the ListBox based on its content
            // UpdateListBoxHeight();
        }

        /*
        private void UpdateListBoxHeight()
        {
            // Set the maximum number of items to display
            int maxVisibleItems = 10; // Adjust this value as needed
            int itemHeight = reviewsListBox.ItemHeight; // Height of each item
            int newHeight = Math.Min(reviewsListBox.Items.Count, maxVisibleItems) * itemHeight + 2; // 2 for padding

            reviewsListBox.Height = newHeight; // Update the ListBox height
        }
        */

        private void back_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the current form
            OptionForm form2 = new OptionForm(library, currentMember);
            form2.Show();
        }
    }
}