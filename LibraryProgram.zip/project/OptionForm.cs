﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;   
using System.Windows.Forms;

namespace project
{
    public partial class OptionForm : Form
    {
        private Library library; // Instance of Library
        private Member currentMember; // Instance of the current member

        public OptionForm(Library library, Member member) // Constructor
        { 
            InitializeComponent();
            this.library = library; // Initialize the library instance
            this.currentMember = member; // Initialize the current member instance
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Ensure that a radio button is selected
            if (!borrowBook.Checked && !returnBook.Checked && !bookReview.Checked && !readReview.Checked)
            {
                MessageBox.Show("Please select an option.");
                return;
            }

            if (borrowBook.Checked)
            {
                BorrowsForm form3 = new BorrowsForm(library, currentMember); // Create the BorrowsForm
                form3.Show(); // Show the form
                this.Hide(); // Hide the current form
            }
            else if (returnBook.Checked)
            {
                ReturnsForm form4 = new ReturnsForm(library,currentMember); // Create the ReturnsForm
                form4.Show(); // Show the form
                this.Hide(); // Hide the current form
            }
            else if (bookReview.Checked)
            {
                ReviewAddForm form5 = new ReviewAddForm(library,currentMember); // ReviewAddForm
                form5.Show(); // Show the form
                this.Hide(); // Hide the current form
            }
            else if (readReview.Checked)
            { 
                ReviewReadForm form6 = new ReviewReadForm(library,currentMember); // ReviewAddForm
                form6.Show(); // Show the form
                this.Hide(); // Hide the current form
            }             
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the current form
            RegisterForm form1 = new RegisterForm(library);
            form1.Show();
        }
    }
}