﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using static project.Book;

namespace project
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Library library = new Library();

            // Adding books to the library
            library.Books.Add(new Book("Murder on the Orient Express", Genre.Mystery, "Agatha Christie", new DateTime(1934, 1, 1), "A detective novel featuring the famous Belgian detective Hercule Poirot as he investigates a murder on the train."));
            library.Books.Add(new Book("The Hobbit", Genre.Fantasy, "JRR Tolkien" , new DateTime(1937, 9, 21), "The adventures of Bilbo Baggins, a hobbit who embarks on a quest with a group of dwarves."));
            library.Books.Add(new Book("Adventures of Huckleberry Finn", Genre.Adventure, "Mark Twain", new DateTime(1884, 12, 10), "A story about a young boy's adventures as he travels down the Mississippi River with an escaped slave."));
            library.Books.Add(new Book("The Hitchhiker's Guide to the Galaxy", Genre.ScienceFiction, "Douglas Adams", new DateTime(1979, 10, 12), "A comedic science fiction series that follows Arthur Dent as he travels through space after Earth is destroyed."));
            library.Books.Add(new Book("The Witness", Genre.Romance, "Nora Roberts", new DateTime(2012, 4, 17), "A story about a woman who witnesses a crime and the complicated relationship that develops as a result."));
            library.Books.Add(new Book("The Terminal List", Genre.Thriller, "Jack Carr", new DateTime(2018, 3, 6), "A military thriller centered around a former Navy SEAL who seeks vengeance against those who wronged him."));

            Application.Run(new RegisterForm(library));
        }
    }
}
