﻿namespace project
{
    partial class OptionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.borrowBook = new System.Windows.Forms.RadioButton();
            this.returnBook = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.signOut = new System.Windows.Forms.Button();
            this.next = new System.Windows.Forms.Button();
            this.bookReview = new System.Windows.Forms.RadioButton();
            this.readReview = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // borrowBook
            // 
            this.borrowBook.AutoSize = true;
            this.borrowBook.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borrowBook.Location = new System.Drawing.Point(129, 168);
            this.borrowBook.Margin = new System.Windows.Forms.Padding(5);
            this.borrowBook.Name = "borrowBook";
            this.borrowBook.Size = new System.Drawing.Size(224, 46);
            this.borrowBook.TabIndex = 0;
            this.borrowBook.TabStop = true;
            this.borrowBook.Text = "Borrow a book";
            this.borrowBook.UseVisualStyleBackColor = true;
            // 
            // returnBook
            // 
            this.returnBook.AutoSize = true;
            this.returnBook.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.returnBook.Location = new System.Drawing.Point(129, 243);
            this.returnBook.Margin = new System.Windows.Forms.Padding(5);
            this.returnBook.Name = "returnBook";
            this.returnBook.Size = new System.Drawing.Size(217, 46);
            this.returnBook.TabIndex = 1;
            this.returnBook.TabStop = true;
            this.returnBook.Text = "Return a book";
            this.returnBook.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(185, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(335, 64);
            this.label1.TabIndex = 2;
            this.label1.Text = "Choose an option";
            // 
            // signOut
            // 
            this.signOut.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signOut.Location = new System.Drawing.Point(35, 474);
            this.signOut.Margin = new System.Windows.Forms.Padding(5);
            this.signOut.Name = "signOut";
            this.signOut.Size = new System.Drawing.Size(174, 56);
            this.signOut.TabIndex = 7;
            this.signOut.Text = "Sign out";
            this.signOut.UseVisualStyleBackColor = true;
            this.signOut.Click += new System.EventHandler(this.button2_Click);
            // 
            // next
            // 
            this.next.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.next.Location = new System.Drawing.Point(511, 474);
            this.next.Margin = new System.Windows.Forms.Padding(5);
            this.next.Name = "next";
            this.next.Size = new System.Drawing.Size(146, 56);
            this.next.TabIndex = 6;
            this.next.Text = "Next";
            this.next.UseVisualStyleBackColor = true;
            this.next.Click += new System.EventHandler(this.button1_Click);
            // 
            // bookReview
            // 
            this.bookReview.AutoSize = true;
            this.bookReview.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookReview.Location = new System.Drawing.Point(129, 319);
            this.bookReview.Margin = new System.Windows.Forms.Padding(5);
            this.bookReview.Name = "bookReview";
            this.bookReview.Size = new System.Drawing.Size(262, 46);
            this.bookReview.TabIndex = 8;
            this.bookReview.TabStop = true;
            this.bookReview.Text = "Leave book review";
            this.bookReview.UseVisualStyleBackColor = true;
            // 
            // readReview
            // 
            this.readReview.AutoSize = true;
            this.readReview.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.readReview.Location = new System.Drawing.Point(129, 395);
            this.readReview.Margin = new System.Windows.Forms.Padding(5);
            this.readReview.Name = "readReview";
            this.readReview.Size = new System.Drawing.Size(256, 46);
            this.readReview.TabIndex = 9;
            this.readReview.TabStop = true;
            this.readReview.Text = "Read book review";
            this.readReview.UseVisualStyleBackColor = true;
            // 
            // OptionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(698, 581);
            this.Controls.Add(this.readReview);
            this.Controls.Add(this.bookReview);
            this.Controls.Add(this.signOut);
            this.Controls.Add(this.next);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.returnBook);
            this.Controls.Add(this.borrowBook);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "OptionForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RuppinLibrary";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton borrowBook;
        private System.Windows.Forms.RadioButton returnBook;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button signOut;
        private System.Windows.Forms.Button next;
        private System.Windows.Forms.RadioButton bookReview;
        private System.Windows.Forms.RadioButton readReview;
    }
}