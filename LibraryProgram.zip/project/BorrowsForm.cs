﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project
{
    public partial class BorrowsForm : Form
    {
        private Library library;
        private Member currentMember;

        public Book SelectedBook { get; set; }
        public BorrowsForm(Library library, Member currentMember)
        {
            InitializeComponent();
            this.library = library;
            this.currentMember = currentMember;            
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // Set the ComboBox to have no items initially
            comboBox1.DataSource = null;

            // Set labels to empty or default text
            labelAuthor.Text = "Author: ";  
            labelGenre.Text = "Genre: ";    
            labelReleaseDate.Text = "Release Date: "; 
            labelSummary.Text = "Summary: "; 
        }


        private void comboBox1_DropDown(object sender, EventArgs e)
        {
            // Load books into the ComboBox only when the dropdown is opened
            comboBox1.DataSource = library.Books.Select(b => b.BookName).ToList();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedBookTitle = comboBox1.SelectedItem?.ToString();

            if (!string.IsNullOrEmpty(selectedBookTitle))
            {
                // Find the selected book in the library
                SelectedBook = library.Books.FirstOrDefault(b => b.BookName.Equals(selectedBookTitle, StringComparison.OrdinalIgnoreCase));

                if (SelectedBook != null)
                {
                    // Update the labels with book details
                    UpdateBookDetails(SelectedBook);
                }
            }
        }

        // Method to update the book details
        private void UpdateBookDetails(Book book)
        {
            labelAuthor.Text = $"Author: {book.BookAuthor}";
            labelGenre.Text = $"Genre: {book.BookGenre}";
            labelReleaseDate.Text = $"Release Date: {book.PublicationDate.ToShortDateString()}";
            labelSummary.Text = $"Summary: {book.Summary}";
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (SelectedBook == null)
            {
                MessageBox.Show("Please select a book.");
                return;
            }

            try
            {
                // Check if the member already has 2 books borrowed
                if (currentMember.BorrowedBooks.Count >= 2)
                {
                    throw new InvalidOperationException("The member has already borrowed the maximum number of books.");
                }

                // Check if the selected book is already borrowed
                if (SelectedBook.IsBorrowed)
                {
                    MessageBox.Show($"{SelectedBook.BookName} is already borrowed\nIt is due back on {SelectedBook.ReturnDate.Value.ToShortDateString()}.");
                    return;
                }

                // If everything is okay, proceed with borrowing the book
                SelectedBook.IsBorrowed = true;
                SelectedBook.ReturnDate = DateTime.Now.AddDays(14);

                // Add the book to the member's list of borrowed books 
                currentMember.BorrowedBooks.Add(SelectedBook);

                MessageBox.Show($"{SelectedBook.BookName} has been selected\nPlease return it by {SelectedBook.ReturnDate.Value.ToShortDateString()}.");
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(ex.Message, "Borrowing Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the current form
            OptionForm form2 = new OptionForm(library, currentMember);
            form2.Show();
        }

    }
}

