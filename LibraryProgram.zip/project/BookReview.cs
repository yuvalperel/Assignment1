﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project
{
    public class BookReview : Book
    {
        // List to hold reviews for the book
        private List<Review> reviews;

        // Constructor
        public BookReview(string name, Genre genre, string author, DateTime publicationDate, string summary)
            : base(name, genre, author, publicationDate, summary)
        {
            reviews = new List<Review>();
        }

        // Property to get all reviews
        public IReadOnlyList<Review> Reviews => reviews.AsReadOnly();

        // Property to allow adding reviews directly
        public void AddNewReview(Review review, Member member)
        {
            // Check if the member has already submitted a review for this book
            if (reviews.Any(r => r.Reviewer == member))
            {
                throw new InvalidOperationException("You have already submitted a review for this book.");
            }

            // Validate that the review text contains only letters and spaces
            if (!string.IsNullOrWhiteSpace(review.ReviewText) &&
                (!review.ReviewText.All(c => char.IsLetter(c) || char.IsWhiteSpace(c)) ||
                 review.ReviewText.All(char.IsDigit)))
            {
                throw new ArgumentException("Review text can only contain letters and spaces, or be empty.");
            }

            // Add the review to the list
            reviews.Add(review);
        }


        // Optional: Method to get the average rating of the reviews
        public double AverageRating
        {
            get
            {
                if (reviews.Count == 0) return 0; // Handle case with no reviews
                return reviews.Average(review => review.Rating);
            }
        }
    }


    // Class to represent a review
    public class Review
    {
        // Private fields
        private int rating;
        private string reviewText;
        private Member reviewer;

        // Public properties to access the fields
        public int Rating
        {
            get { return rating; }
            private set
            {
                if (value < 1 || value > 5)
                {
                    throw new ArgumentException("Rating must be between 1 and 5.");
                }
                rating = value;
            }
        }

        public string ReviewText
        {
            get { return reviewText; }
            private set
            {
                if (!IsValidReviewText(value))
                {
                    throw new ArgumentException("Review text must consist of letters or spaces only and cannot be a string of only numbers.");
                }
                reviewText = value;
            }
        }

        public Member Reviewer
        {
            get { return reviewer; }
            private set
            {
                reviewer = value ?? throw new ArgumentNullException(nameof(value), "Reviewer cannot be null.");
            }
        }

        // Constructor
        public Review(int rating, string reviewText, Member reviewer)
        {
            Rating = rating;
            ReviewText = reviewText;
            Reviewer = reviewer;
        }

        // Validation method for review text
        private bool IsValidReviewText(string reviewText)
        {
            // Check if the text contains only letters and spaces, and is not a string of only numbers
            return string.IsNullOrWhiteSpace(reviewText) || (reviewText.All(c => char.IsLetter(c) || char.IsWhiteSpace(c)) && !reviewText.All(char.IsDigit));
        }
    }
}