﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using project;
using static project.Program;


namespace project
{ 
    public partial class RegisterForm : Form
    {
        private Library library;

        private Member currentMember; // in order to save data of the current member

        public RegisterForm(Library library)
        {
            InitializeComponent();
            this.library = library;

        }

        private void RegisterForm_Load(object sender, EventArgs e)
        {
            labelWelcome.Text = "Welcome to Ruppin's library";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string firstNameInput = this.firstName.Text.Trim();
            string lastNameInput = this.lastName.Text.Trim();
            string idInput = this.id.Text.Trim();

            // Validate ID and Name using the Member class constructor and properties
            try
            {
                currentMember = new Member(idInput, firstNameInput, lastNameInput); // Constructor handles validation
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message); // Show the validation error message from the Member class
                return;
            }

            // Checking if the member exists in the list
            var existingMember = library.Members.FirstOrDefault(m =>
                m.FirstName.Equals(firstNameInput, StringComparison.OrdinalIgnoreCase) &&
                m.LastName.Equals(lastNameInput, StringComparison.OrdinalIgnoreCase)); 

            if (existingMember != null)
            {
                if (existingMember.MemberID.Equals(idInput))
                {
                    MessageBox.Show("Member logged in successfully.");
                    currentMember = existingMember;
                    OptionForm optionForm = new OptionForm(library, currentMember);
                    this.Hide();
                    optionForm.Show();
                }
                else
                {
                    MessageBox.Show("Member ID is incorrect. Please try again.");
                }
            }
            else if (library.Members.Any(m => m.MemberID.Equals(idInput)))
            {
                MessageBox.Show("A member with the given ID already exists. Please try again.");
            }
            else
            {
                library.Members.Add(currentMember);
                MessageBox.Show("Member registered successfully.");
                OptionForm optionForm = new OptionForm(library, currentMember);
                this.Hide();
                optionForm.Show();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit(); // Close all forms and applications
        }

    }
}
