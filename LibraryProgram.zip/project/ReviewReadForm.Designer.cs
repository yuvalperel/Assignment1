﻿namespace project
{
    partial class ReviewReadForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.booksComboBox = new System.Windows.Forms.ComboBox();
            this.back = new System.Windows.Forms.Button();
            this.labelAverage = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelReviews = new System.Windows.Forms.Label();
            this.reviewsListBox = new System.Windows.Forms.ListBox();
            this.averageRatingLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // booksComboBox
            // 
            this.booksComboBox.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.booksComboBox.FormattingEnabled = true;
            this.booksComboBox.Location = new System.Drawing.Point(49, 131);
            this.booksComboBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.booksComboBox.Name = "booksComboBox";
            this.booksComboBox.Size = new System.Drawing.Size(611, 50);
            this.booksComboBox.TabIndex = 9;
            this.booksComboBox.DropDown += new System.EventHandler(this.comboBox1_DropDown);
            this.booksComboBox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // back
            // 
            this.back.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back.Location = new System.Drawing.Point(12, 540);
            this.back.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(150, 67);
            this.back.TabIndex = 10;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // labelAverage
            // 
            this.labelAverage.AutoSize = true;
            this.labelAverage.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAverage.Location = new System.Drawing.Point(57, 250);
            this.labelAverage.Name = "labelAverage";
            this.labelAverage.Size = new System.Drawing.Size(211, 42);
            this.labelAverage.TabIndex = 12;
            this.labelAverage.Text = "Average Rating:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(53, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(279, 64);
            this.label1.TabIndex = 8;
            this.label1.Text = "Choose a book";
            // 
            // labelReviews
            // 
            this.labelReviews.AutoSize = true;
            this.labelReviews.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelReviews.Location = new System.Drawing.Point(56, 308);
            this.labelReviews.Name = "labelReviews";
            this.labelReviews.Size = new System.Drawing.Size(118, 42);
            this.labelReviews.TabIndex = 13;
            this.labelReviews.Text = "Reviews:";
            // 
            // reviewsListBox
            // 
            this.reviewsListBox.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reviewsListBox.FormattingEnabled = true;
            this.reviewsListBox.ItemHeight = 42;
            this.reviewsListBox.Location = new System.Drawing.Point(180, 320);
            this.reviewsListBox.Name = "reviewsListBox";
            this.reviewsListBox.Size = new System.Drawing.Size(621, 214);
            this.reviewsListBox.TabIndex = 17;
            // 
            // averageRatingLabel
            // 
            this.averageRatingLabel.AutoSize = true;
            this.averageRatingLabel.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.averageRatingLabel.Location = new System.Drawing.Point(274, 250);
            this.averageRatingLabel.Name = "averageRatingLabel";
            this.averageRatingLabel.Size = new System.Drawing.Size(0, 42);
            this.averageRatingLabel.TabIndex = 18;
            // 
            // ReviewReadForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(956, 639);
            this.Controls.Add(this.averageRatingLabel);
            this.Controls.Add(this.reviewsListBox);
            this.Controls.Add(this.labelReviews);
            this.Controls.Add(this.labelAverage);
            this.Controls.Add(this.back);
            this.Controls.Add(this.booksComboBox);
            this.Controls.Add(this.label1);
            this.Name = "ReviewReadForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RuppinLibrary";
            this.Load += new System.EventHandler(this.ReviewReadForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox booksComboBox;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Label labelAverage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelReviews;
        private System.Windows.Forms.ListBox reviewsListBox;
        private System.Windows.Forms.Label averageRatingLabel;
    }
}