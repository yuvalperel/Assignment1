﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static project.Book;

namespace project
{
    public class Library
    {
        public List<Book> Books { get; private set; } // List of books in the library
        public List<Member> Members { get; private set; } // List of existing members

        public List<BookReview> BookReviews { get; private set; } // List of books that have a review 

        // Constructor
        public Library()
        {
            Books = new List<Book>(); // Initialize the Books list
            Members = new List<Member>(); // Initialize the Members list
            BookReviews = new List<BookReview>(); // Initialize the BookReviewS list
        }

        // Method to add a book review to the library
        public void AddBookReview(BookReview bookReview)
        {
            var existingReview = BookReviews.FirstOrDefault(br => br.BookName == bookReview.BookName);
            if (existingReview == null)
            {
                BookReviews.Add(bookReview);
            }
            else
            {
                // If the book already has a review, just add the review to the existing book
                existingReview.AddNewReview(bookReview.Reviews.FirstOrDefault(), bookReview.Reviews.FirstOrDefault().Reviewer);
            }
        }

        // Method to get a specific book review by book name
        public BookReview GetBookReview(string bookName)
        {
            return BookReviews.FirstOrDefault(br => br.BookName == bookName);
        }
    }
}
