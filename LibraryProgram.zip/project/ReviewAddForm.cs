﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project
{
    public partial class ReviewAddForm : Form
    {
        private Library library;
        private Member currentMember;

        public ReviewAddForm(Library library,Member member)
        {
            InitializeComponent();
            this.library = library;
            this.currentMember = member;
        }

        private void ReviewAddForm_Load(object sender, EventArgs e)
        {
            // Load returned books into the ListBox
            LoadReturnedBooks();
        }

        private void LoadReturnedBooks()
        {
            booksListBox.Items.Clear(); // Clear existing items

            var returnedBooks = currentMember.ReturnedBooks.ToList();

            if (returnedBooks.Count > 0)
            {
                foreach (var book in returnedBooks)
                {
                    booksListBox.Items.Add(book.BookName); // Displaying the book object directly
                }
            }
            else
            {
                booksListBox.Items.Add("No returned books to review.");
            }
        }

        private void apply_Click(object sender, EventArgs e)
        {
            if (booksListBox.SelectedItem == null || booksListBox.SelectedItem.ToString() == "No returned books to review.")
            {
                MessageBox.Show("Please select a book to review.");
                return;
            }

            // Get the selected book name
            var selectedBookName = booksListBox.SelectedItem.ToString();
            // Find the selected book in the current member's returned books
            var selectedBook = currentMember.ReturnedBooks.FirstOrDefault(book => book.BookName == selectedBookName);

            if (selectedBook == null)
            {
                MessageBox.Show("Selected book not found.");
                return;
            }

            int rating = (int)ratingNum.Value;
            string reviewText = reviewTextBox.Text;

            try
            {
                var review = new Review(rating, reviewText, currentMember);

                // Get existing BookReview or create a new one
                var bookReview = library.GetBookReview(selectedBookName);

                // If no existing review found, create a new BookReview
                if (bookReview == null)
                {
                    bookReview = new BookReview(selectedBook.BookName, selectedBook.BookGenre, selectedBook.BookAuthor, selectedBook.PublicationDate, selectedBook.Summary);
                    library.AddBookReview(bookReview); // Add the new BookReview to the library
                }

                // Add the new review to the BookReview
                bookReview.AddNewReview(review, currentMember);

                MessageBox.Show("Review added successfully!");
                LoadReturnedBooks(); // Reload the list to reflect the new review
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Hide(); 
            OptionForm form2 = new OptionForm(library, currentMember);
            form2.Show();
        }
    }
}
